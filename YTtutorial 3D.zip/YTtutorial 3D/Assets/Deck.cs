﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Deck : MonoBehaviour
{
    public static Deck instance;
    public GameObject hand;
    public GameObject cardPrefab;

    private List<Card> deckCards = new List<Card>();
    private List<Card> usedCards = new List<Card>();
    private List<Card> cardsInHand;
    private List<Card> cardsInTimeline;

    // Start is called before the first frame update
    void Start()
    {
        this.loadDeck();
        this.SetNewHand(2); 
        /*Debug.Log("Inicio del Script Start");
        GameObject newCard = Instantiate(cardPrefab, transform.position, Quaternion.identity);
        newCard.transform.SetParent(hand.transform);
        Debug.Log("Hand position: " + hand.transform.position);
        Debug.Log("Fin del Script Start");*/
    }

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }   

    public void SetNewHand(int size)
    {
        for(int i = 0; i < size; i++)
        {
            this.AddCardToHand();
        }
        Debug.Log("New hand is ready.");
    }

    public void AddCardToHand()
    {
        Debug.Log("Enters AddCardToHand()");        
        Card cardSO = this.GetRandomCard();
        if (cardSO != null)
        {
            GameObject newCard = new GameObject();
            newCard = Instantiate(instance.cardPrefab, instance.transform.position, Quaternion.identity);
            newCard.GetComponent<CardDisplay>().card = cardSO;
            newCard.transform.SetParent(instance.hand.transform);
            Debug.Log("Card " + newCard.GetComponent<CardDisplay>().card.cardID + " added to hand.");
        }
        else
        {
            Debug.Log("No se pudo agregar más cartas");
        }
    }

    public bool CardExistsInHand(Card newCard)
    {
        return true;
    }

    public void loadDeck()
    {
        deckCards.Clear();
        usedCards.Clear();
        //cardsInHand.Clear();
        //cardsInTimeline.Clear();
        foreach(Card card in Database.GetAllCards())
        {
            deckCards.Add(card);
        }
    }

    public Card GetRandomCard()
    {
        if(deckCards.Count > 0)
        {
            int cardPos = Random.Range(0, deckCards.Count);
            Card newCard = deckCards[cardPos];

            usedCards.Add(newCard);
            deckCards.RemoveAt(cardPos);

            Debug.Log("Card Position: " + cardPos);
            Debug.Log("Card selected: " + newCard.cardName);

            return newCard;
        }
        else
        {
            Debug.Log("El Deck está vacío");
            return null;
        }
    }

}
