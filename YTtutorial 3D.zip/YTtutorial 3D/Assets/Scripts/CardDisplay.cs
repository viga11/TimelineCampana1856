﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CardDisplay : MonoBehaviour
{

    public Card card;

    public Text nameText;
    public Text descriptionText;
    public Image artworkImage;

    //hacer el text de mana, attack y heal

    // Start is called before the first frame update
    void Start()
    {
        //Debug.Log(card.cardName);
        if(card != null)
        {
            card.Print();
            nameText.text = card.cardName;
            descriptionText.text = card.description;
            artworkImage.sprite = card.artworkFront;
        }
    }

    public void setCardSide(DropZone.Slot zone){
        //Draggable.Slot typeOfZone = Draggable.Slot.TIMELINE;
        if(card != null)
        {
            if (zone == DropZone.Slot.TIMELINE)
            {
                artworkImage.sprite = card.artworkBack;
            }
            else
            {
                artworkImage.sprite = card.artworkFront;
            }
        }        
    }


}
