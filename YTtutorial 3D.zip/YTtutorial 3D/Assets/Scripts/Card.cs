﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Card", menuName = "My Assets/Card")] //para submenu: menuName = "Cards/Minion"
public class Card : ScriptableObject
{
    public int cardID;
    public string cardName;    
    [TextArea]
    public string description;
    
    //public System.DateTime fecha;
    public int anno;
    public short mes;
    public short dia;

    public string ubicacion; //seguro es un int, y en el mapa se marcan las ubicaciones como por zonas

    public Sprite artworkFront;
    public Sprite artworkBack;

    //Methods
    public void Print(){
        Debug.Log(cardName + ": " + description + "\n\tFecha: " + dia + "/" + mes + "/" + anno);
    }


}
