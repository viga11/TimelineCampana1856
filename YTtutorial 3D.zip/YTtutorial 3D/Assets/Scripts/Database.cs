﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class Database : MonoBehaviour
{   
    private static Database instance;
    public CardDatabase cards;

    private void Awake()
    {
        if(instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public static Card GetCardByID(int ID)
    {
        //Otra opción:
        //return instance.cards.allCards.FirstOrDefault(c => c.cardID == ID); //Devuelve el primero que haga match y sino da null
        foreach(Card card in instance.cards.allCards)
        {
            if(ID == card.cardID)
            {
                return card;
            }
        }
        return null;
    }

    public static Card GetRandomCard()
    {
        int cardId = Random.Range(0, instance.cards.allCards.Count());
        Debug.Log("Card ID selected: " + cardId);
        return instance.cards.allCards[cardId];
    }

    public static List<Card> GetAllCards()
    {
        return instance.cards.allCards;
    }

}
