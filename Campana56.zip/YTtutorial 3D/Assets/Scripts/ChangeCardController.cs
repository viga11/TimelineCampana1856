﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using NDream.AirConsole;
using Newtonsoft.Json.Linq;
public class ChangeCardController : MonoBehaviour
{

    // Use this for initialization
    public int index;
    public GameObject hand;
    public GameObject timeline;
    
    [SerializeField] bool keyDown;    
    [SerializeField] int maxIndex; //el maximo deberia ser la cantidad de cartas en la mano.    

   
    public int activeZone = 0; // 0 es hand y 1 es timeline

    public AudioSource audioSource;

    void Start()
    {
        //audioSource = GetComponent<AudioSource>();
    }
    void Awake()
    {
        AirConsole.instance.onMessage += OnMessage;
    }

    
	void Update () {             
        if(activeZone == 0) //Si la zona activa es la mano
        {
            maxIndex = hand.transform.childCount - 1;
            if (Input.GetAxis("Horizontal") != 0)
            {
                if (!keyDown)
                {
                    if (Input.GetAxis("Horizontal") > 0)
                    {
                        if (index < maxIndex)
                        {
                            index++;
                        }
                        else
                        {
                            index = 0;
                        }
                    }
                    else if (Input.GetAxis("Horizontal") < 0)
                    {
                        if (index > 0)
                        {
                            index--;
                        }
                        else
                        {
                            index = maxIndex;
                        }
                    }
                    keyDown = true;
                }
            }

            else
            {
                keyDown = false;
            }

        }           

    }
	

    // funcio que se encarga de leer los mensajes enviados por los controles
    void OnMessage(int fromDeviceID, JToken data)
    {
        if (activeZone == 3) //Si la zona activa es la mano
        {
            maxIndex = hand.transform.childCount - 1;
            //imprime en consola la informacion que recibe
            Debug.Log("Mensaje enviado por dispositivo: " + fromDeviceID + ", data: " + data);
            //filtros de la informacion por botones (entre las direcciones del pad y el boton)

            //filtro boton A
            if (data["element"] != null && data["element"].ToString().Equals("botonA"))
            {

            }
            //filtro boton B
            if (data["element"] != null && data["element"].ToString().Equals("botonB"))
            {

            }

            //filtro dpad
            //Debug.Log("Si llego "+ (data["data"]["pressed"].ToString().Equals("True")));
            if (data["element"] != null && data["element"].ToString().Equals("dpad") && (data["data"]["pressed"].ToString().Equals("True")))
            {
                //arriba pressed
                if (data["data"]["key"].ToString().Equals("up"))
                {

                }
                //abajo
                else if (data["data"]["key"].ToString().Equals("down"))
                {

                }
                //izquierda
                else if (data["data"]["key"].ToString().Equals("left"))
                {
                    if (index > 0)
                    {
                        index--;
                    }
                    else
                    {
                        index = maxIndex;
                    }

                }
                //derecha
                else if (data["data"]["key"].ToString().Equals("right"))
                {
                    if (index < maxIndex)
                    {
                        index++;
                    }
                    else
                    {
                        index = 0;
                    }
                }
            }
        }
    }

    void OnMessage2(int fromDeviceID, JToken data)
    {
        maxIndex = hand.transform.childCount - 1;
        //imprime en consola la informacion que recibe
        Debug.Log("Mensaje enviado por dispositivo: " + fromDeviceID + ", data: " + data);
        //filtros de la informacion por botones (entre las direcciones del pad y el boton)

        //filtro boton A
        if (data["element"] != null && data["element"].ToString().Equals("botonA"))
        {

        }
        //filtro boton B
        if (data["element"] != null && data["element"].ToString().Equals("botonB"))
        {

        }

        //filtro dpad
        //Debug.Log("Si llego "+ (data["data"]["pressed"].ToString().Equals("True")));
        if (data["element"] != null && data["element"].ToString().Equals("dpad") && (data["data"]["pressed"].ToString().Equals("True")))
        {
            //arriba pressed
            if (data["data"]["key"].ToString().Equals("up"))
            {
                if (index > 0)
                {
                    index--;
                }
                else
                {
                    index = maxIndex;
                }
            }
            //abajo
            else if (data["data"]["key"].ToString().Equals("down"))
            {
                if (index < maxIndex)
                {
                    index++;
                }
                else
                {
                    index = 0;
                }
            }
            //izquierda
            else if (data["data"]["key"].ToString().Equals("left"))
            {

            }
            //derecha
            else if (data["data"]["key"].ToString().Equals("right"))
            {

            }
        }
    }

    void OnDestroy()
    {

        //unregister events
        if (AirConsole.instance != null)
        {
            AirConsole.instance.onMessage -= OnMessage;
        }
    }
}
