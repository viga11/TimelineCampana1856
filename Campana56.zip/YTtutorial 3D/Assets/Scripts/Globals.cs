﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public static class Globals 
{
	//globales staticas se utilizan en la Rotación (se debe cambiar)
	public static int posicion = 2;
	public static int numeroPersonaje = 3;
	public static string nombreS = "";
	public static string apellidoS = "";
	public static string usuarioS = "";
	public static Sprite imagenP;
}
