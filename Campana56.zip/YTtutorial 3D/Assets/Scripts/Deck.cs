﻿using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using UnityEngine;
//using UnityEngine.TestTools;

public class Deck : MonoBehaviour
{
    public static Deck instance;
    public GameObject hand;
    public GameObject timeline;
    public GameObject cardPrefab;

    private List<Card> allCards = new List<Card>();
    private List<Card> deckCards = new List<Card>();
    private List<Card> usedCards = new List<Card>();
    //private List<Card> cardsInHand;
    //private List<Card> cardsInTimeline;

    // Start is called before the first frame update
    void Start()
    {
        this.LoadDeck();
        this.SetFirstCard();
        //this.SetNewHand(4);
    }

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }   

    public void SetNewHand(int size)
    {
        for(int i = 0; i < size; i++)
        {
            this.AddCardToHand();
        }
        //Debug.Log("New hand is ready.");
    }

    public void AddCardToHand()
    {
        //Debug.Log("Enters AddCardToHand()");        
        Card cardSO = this.GetRandomCard();
        if (cardSO != null)
        {            
            GameObject newCard = Instantiate(instance.cardPrefab, instance.transform.position, Quaternion.identity);
            newCard.GetComponent<CardDisplay>().card = cardSO;
            newCard.transform.SetParent(instance.hand.transform);
            //Debug.Log("Card " + newCard.GetComponent<CardDisplay>().card.cardID + " added to hand.");
        }
        else
        {
            Debug.Log("No se pudo agregar más cartas");
        }
    }

    
    
    
    
    
    
    
    //add card to han
    public void PlaceCardInHandZone(Card cardSO)
    {        
        //Card cardSO = this.GetRandomCard();
        if (cardSO != null)
        {
            GameObject newCard = Instantiate(instance.cardPrefab, instance.transform.position, Quaternion.identity);
            newCard.GetComponent<CardDisplay>().card = cardSO;
            newCard.transform.SetParent(instance.hand.transform);
            //Debug.Log("Card " + newCard.GetComponent<CardDisplay>().card.cardID + " added to hand.");
        }
        else
        {
            Debug.Log("No se pudo agregar carta");
        }
    }

    //set new hand receiving hand
    public void PlaceHandInHandZone(List<int> playersHand)
    {
        //Limpiar mano
        this.CleanHandZone();
       
        List<Card> currentHand = getHandByID(playersHand);

        //Colocar cartas de la mano que recibió
        for (int i = 0; i < currentHand.Count; i++)
        {
            this.PlaceCardInHandZone(currentHand[i]);
        }
    }

    public List<Card> getHandByID(List<int> playersHand)
    {
        List<Card> currentHand = new List<Card>();
        foreach(int i in playersHand)
        {
            currentHand.Add(this.getCardByID(i));
        }

        return currentHand;
    }

    public Card getCardByID(int id)
    {
        foreach(Card c in allCards)
        {
            if(c.cardID == id)
            {
                return c;
            }
        }
        return null;
        
    }

    public void CleanHandZone()
    {
        //limpiar mano
        foreach (Transform child in hand.transform)
        {
            GameObject.Destroy(child.gameObject);
        }
    }


    public int GetNewCard()
    {
        int id = this.GetRandomCard().cardID;
        return id;
    }

    //create new hand
    public List<int> CreateNewHand(int tamano)
    {

        List<int> newHand = new List<int>();
        for(int i = 0; i < tamano; i++)
        {
            newHand.Add(this.GetRandomCard().cardID);
        }
        return newHand;
    }

    

    public void SetFirstCard()
    {
        //Debug.Log("Enters SetFirstCard()");        
        Card cardSO = this.GetRandomCard();
        if (cardSO != null)
        {
            GameObject newCard = Instantiate(instance.cardPrefab, instance.transform.position, Quaternion.identity);
            newCard.GetComponent<CardDisplay>().card = cardSO;
            newCard.transform.SetParent(instance.timeline.transform);
            newCard.GetComponent<CardDisplay>().turnCardSide(1);
            newCard.GetComponent<ChangeCard>().setPlayed(true);
            //Debug.Log("Card " + newCard.GetComponent<CardDisplay>().card.cardID + " set as first in timeline.");
        }
        else
        {
            Debug.Log("No se encontró ninguna carta para colocar en el Timeline");
        }

    }

    public void LoadDeck()
    {
        deckCards.Clear();
        usedCards.Clear();
        //cardsInHand.Clear();
        //cardsInTimeline.Clear();
        foreach(Card card in Database.GetAllCards())
        {
            deckCards.Add(card);
            allCards.Add(card);
        }
    }

    public Card GetRandomCard()
    {
        if(deckCards.Count > 0)
        {
            int cardPos = Random.Range(0, deckCards.Count);
            Card newCard = deckCards[cardPos];

            usedCards.Add(newCard);
            deckCards.RemoveAt(cardPos);

            //Debug.Log("Card Position: " + cardPos);
            //Debug.Log("Card selected: " + newCard.cardName);

            return newCard;
        }
        else
        {
            Debug.Log("El Deck está vacío");
            Debug.Log("---Fin del juego---");
            return null;
        }
    }

}
