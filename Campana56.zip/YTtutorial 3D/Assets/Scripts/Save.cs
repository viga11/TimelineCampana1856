﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEditor;

public class Save : MonoBehaviour
{

    private PlayerData player;
    static public string Usuario1;
    public Image use;
    public GameObject inputFieldnombre;
    public GameObject inputFieldapeelido;
    public GameObject inputFieldusuario;
    // Start is called before the first frame update
    public void SetValues()
    {   
        //Funcion de guardado para el Boton
        Usuario1 = inputFieldusuario.GetComponent<Text>().text;
        PersistantManager.usuarioEnUso = Usuario1;
    
        SaveSystem.SavePlayer( inputFieldnombre.GetComponent<Text>().text,inputFieldapeelido.GetComponent<Text>().text,Usuario1,use.GetComponent<Image>().sprite.name);
        SceneManager.LoadScene(3);
    }
 




}
