﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class PlayerData 
{
//Clase que se puede guardar en un archivo "\AppData\LocalLow\DefaultCompany\Profile" en ese path si se desean ver
	public string nombre;
	public string apellido;
	public string usuario;
	public int puntaje;
	public string personaje;

	public List<int> mano;

	public PlayerData(string n1 , string n2,string n3,string n4){
		this.nombre = n1;
		this.apellido = n2;
		this.usuario = n3;
		this.personaje = n4;
		this.puntaje = 0;
		this.mano = new List<int>();
	}

	public void AddCardToPlayerHand(int id)
	{
		mano.Add(id);
	}

	public void RemoveCardFromPlayerHand(int id)
	{
		mano.Remove(id);
	}

	public void SetPlayerHand(List<int> nuevaMano)
	{
		this.mano = nuevaMano;
	}

	public List<int> GetHand()
	{
		return mano;
	}

}
