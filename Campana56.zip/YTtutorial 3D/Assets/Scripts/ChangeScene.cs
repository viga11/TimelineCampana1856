﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class ChangeScene : MonoBehaviour
{
    //Cambio de Escena le entra por parametro el numero de la escena
    public void changeSceneMethod(int sceneToChange)
    {
        SceneManager.LoadScene(sceneToChange);
    }


}
