﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;
using UnityEngine.SceneManagement;
public class Load : MonoBehaviour
{
	public Text nTexto;
	public Text aTexto;
	public Text uTexto;
	public Text Puntaje;
	private Image selected;

	private static Text n1TextAll;
	private static Text n2TextAll;
	private static Image i1TextAll;

	private Sprite selectedSpriteL;

	public void loadPersonaje(string usuariov)
	{
		//Carga de personajes por nombre de Usuario en la Escena de Profile Solamente
		PlayerData data = SaveSystem.LoadPlayer(usuariov);
		nTexto.text = data.nombre;
		aTexto.text = data.apellido;
		uTexto.text = data.usuario;
		Puntaje.text = data.puntaje.ToString();
		selected = GameObject.Find("Seleccionada").GetComponent<Image>();
		Sprite selectedSpriteL = Resources.Load<Sprite>(data.personaje);
		selected.sprite = selectedSpriteL;

	}
	public static void loadPersonajePath(string path)
	{
		// Carga de Personaje Auxiliar , en escena por path , esta abierta a cambios dependiendo de lo que se necesite
		PlayerData data = SaveSystem.LoadPlayerByPath(path);
		if (data != null)
		{
			n1TextAll = GameObject.Find("Usuario").GetComponent<Text>();
			i1TextAll = GameObject.Find("Seleccionada").GetComponent<Image>();
			n2TextAll = GameObject.Find("Score").GetComponent<Text>();
			n1TextAll.text = data.usuario;
			n2TextAll.text = data.puntaje.ToString();
			Sprite selectedSprite = Resources.Load<Sprite>(data.personaje);
			i1TextAll.sprite = selectedSprite;
		}

	}
	void Start()
	{
		//Inicio solo para la escena de Perfil Profile
		int y = SceneManager.GetActiveScene().buildIndex;
		if (y == 3)
		{
			loadPersonaje(PersistantManager.usuarioEnUso);
		}
	}
}

