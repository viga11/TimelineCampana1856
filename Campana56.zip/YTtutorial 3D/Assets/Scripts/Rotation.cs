﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Rotation : MonoBehaviour
{
 public Sprite newImage1;
 public Sprite newImage2;
 public Sprite newImage3;

 private Image myIMGcomponent1;
 private Image myIMGcomponent2;
 private Image myIMGcomponent3;
 private int numeroDePersonajes;
 private int posicionP;
 // Use this for initialization
    private List<Image> images = new List<Image>();
    private List<Sprite> nombres = new List<Sprite>();

 void Start () {
    //Rotación de los personajes que estan para que el jugador pueda seleccionar quien es 
     myIMGcomponent1 = GameObject.Find("Atras").GetComponent<Image> ();
     myIMGcomponent2 =  GameObject.Find("Seleccionada").GetComponent<Image> ();
     myIMGcomponent3 =  GameObject.Find("Adelante").GetComponent<Image> ();
     images.Add(myIMGcomponent1);
     images.Add(myIMGcomponent2);
     images.Add(myIMGcomponent3);
     nombres.Add(newImage1);
     nombres.Add(newImage2);
     nombres.Add(newImage3);


 }
 public void setSprite () {
    numeroDePersonajes = Globals.numeroPersonaje;
    posicionP = Globals.posicion;
   
     
    Sprite desechable = nombres[0];
    Sprite desechable2 = nombres[1];
    nombres[0] = nombres[2];
    nombres[1] = desechable;
    nombres[2] = desechable2;

    for(int i =0; i<numeroDePersonajes;i++){
        images[i].sprite = nombres[i];
    }     

 }
 public void backSprite(){
    numeroDePersonajes = Globals.numeroPersonaje;
    posicionP = Globals.posicion;
   
     
    Sprite desechable = nombres[2];
    Sprite desechable2 = nombres[0];
    nombres[0] = nombres[1];
    nombres[1] = desechable;
    nombres[2] = desechable2;

    for(int i =0; i<numeroDePersonajes;i++){
        images[i].sprite = nombres[i];
    }


 }
 
 // Update is called once per frame
 void Update () {
     
 }

}
