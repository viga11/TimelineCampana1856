﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Experimental.UIElements;
using UnityEngine.UI;

public class ChangeCard : MonoBehaviour
{
	[SerializeField] ChangeCardController buttonController;
	//[SerializeField] Animator animator;
	//[SerializeField] AnimatorFunctions animatorFunctions;
	//[SerializeField] int thisIndex;
	private int thisIndex;
	private int handIndex;
	
	private bool current;
	private int zona = 0; //0 es la mano y 1 es el timeline //eliminar
	private bool selected = false;
	private bool played = false;
	private float canvasWidth;

	private void Start()
	{
		buttonController = GetComponentInParent<Canvas>().GetComponent<ChangeCardController>();
		current = false;
		canvasWidth = this.GetComponentInParent<Canvas>().GetComponent<RectTransform>().rect.width;
	}

	void Update()
	{
		this.thisIndex = this.transform.GetSiblingIndex();

		if (!played)
		{
			if (buttonController.index == thisIndex) //zona == buttonController.activeZona
			{
				if (!current)
				{
					this.HighlightCard();
					current = true;

				}

				else if (current)
				{
					if (Input.GetKeyDown("up"))
					{						
						buttonController.index = -1;
						this.handIndex = thisIndex;
						int timeLineIndex = buttonController.timeline.transform.childCount / 2;
						this.thisIndex = timeLineIndex;
						this.transform.SetParent(buttonController.timeline.transform);
						this.transform.SetSiblingIndex(thisIndex);
						buttonController.activeZone = 1;

						if (buttonController.timeline.transform.childCount % 2 == 0)
						{
							//Mover Timeline
							Vector3 ubicacionTimeline = buttonController.timeline.transform.position;
							float cardWidth = this.GetComponent<RectTransform>().rect.width;
							ubicacionTimeline.x = ubicacionTimeline.x + (cardWidth / 2.0f);
							this.transform.parent.transform.position = ubicacionTimeline;
						}

						selected = true;
					}
				}
			}
			else if (selected)
			{
				if (Input.GetKeyDown("right"))
				{
					if (thisIndex < buttonController.timeline.transform.childCount - 1) //Revisa si es la última carta del timeline
					{
						//Escoge carta a la derecha y moverla una posición a la izquierda
						buttonController.timeline.transform.GetChild(thisIndex + 1).SetSiblingIndex(thisIndex);
						
						//Mover el timeline
						Vector3 ubicacionTimeline = buttonController.timeline.transform.position;
						float cardWidth = this.GetComponent<RectTransform>().rect.width;
						ubicacionTimeline.x = ubicacionTimeline.x - cardWidth - 3;
						this.transform.parent.transform.position = ubicacionTimeline;
					}
					else
					{
						Debug.Log("No hay más cartas a la derecha");
					}

				}
				else if (Input.GetKeyDown("left"))
				{
					if (thisIndex > 0) //Revisa si es la primera carta del timeline
					{
						//Escoge carta a la izquierda y moverla una posición a la izquierda
						buttonController.timeline.transform.GetChild(thisIndex - 1).SetSiblingIndex(thisIndex);

						//Mover el timeline
						Vector3 ubicacionTimeline = buttonController.timeline.transform.position;	
						float cardWidth = this.GetComponent<RectTransform>().rect.width;
						ubicacionTimeline.x = ubicacionTimeline.x + cardWidth + 3;						
						this.transform.parent.transform.position = ubicacionTimeline;
					}
					else
					{
						Debug.Log("No hay más cartas a la izquierda");
					}

				}
				else if (Input.GetKeyDown("a"))
				{
					Vector3 ubicacionTimeline = buttonController.timeline.transform.position;
					ubicacionTimeline.x = canvasWidth/2.0f;
					buttonController.timeline.transform.position = ubicacionTimeline;
					if (this.validarPosicionDeCarta()) //validar el año de la carta
					{
						if(buttonController.hand.transform.childCount == 0)
						{
							this.HighlightForTimeline();

							Debug.Log(PersistantManager.instance.getCurrentPlayer() + " GANÓ EL JUEGO");
							TurnSystem.instance.changeMessage(3);
						}
						else
						{
							Debug.Log("Soy valido");
							TurnSystem.instance.changeMessage(1);
							this.SetAsPlayed();
							buttonController.index = 0;
							buttonController.activeZone = 0;
							
							TurnSystem.instance.ChangeTurn(this.GetComponent<CardDisplay>().card.cardID);	
						}						
					}
					else
					{
						Debug.Log("No soy valido");
						TurnSystem.instance.changeMessage(2);
						buttonController.index = 0;
						buttonController.activeZone = 0;
										
						TurnSystem.instance.FailedPlay();
						TurnSystem.instance.ChangeTurn(this.GetComponent<CardDisplay>().card.cardID);

						Destroy(gameObject);

					}

				}
				else if (Input.GetKeyDown("down"))
				{
					//CUANDO BAJO SE MUEVE MENOS 115.
					//Center Timeline
					Vector3 ubicacionTimeline = buttonController.timeline.transform.position;
					//float cardWidth = this.GetComponent<RectTransform>().rect.width;
					ubicacionTimeline.x = canvasWidth/2.0f;
					this.transform.parent.transform.position = ubicacionTimeline;

					this.thisIndex = handIndex;
					buttonController.index = thisIndex;
					this.transform.SetParent(buttonController.hand.transform);
					this.transform.SetSiblingIndex(thisIndex);
					buttonController.activeZone = 0;					

					selected = false;
				}

			}
			else
			{
				this.UnhighlightCard();
				current = false;
			}

		}		
	}

	public void HighlightCard()
	{
		this.GetComponent<UnityEngine.UI.Image>().color = new Color32(102, 249, 122, 255);
		Vector3 scaleChange = new Vector3(0.06f, 0.06f, 0f);
		this.transform.localScale += scaleChange;
	}

	public void UnhighlightCard()
	{
		this.GetComponent<UnityEngine.UI.Image>().color = new Color32(124, 169, 248, 255);
		Vector3 scaleChange = new Vector3(1f, 1f, 0f);
		this.transform.localScale = scaleChange;
	}

	public void HighlightForTimeline()
	{
		this.UnhighlightCard();

		this.GetComponent<UnityEngine.UI.Image>().color = new Color32(245, 94, 70, 255);

		//float cardWidth = gameObject.GetComponent<RectTransform>().rect.width;
		//gameObject.GetComponent<RectTransform>().sizeDelta.x = 2;

		Vector3 scaleChange = new Vector3(0.05f, 0.05f, 0f);
		this.transform.localScale += scaleChange;


	}

	public void SetAsPlayed()
	{		
		this.HighlightForTimeline();
		played = true;
		CardDisplay cd = this.GetComponent<CardDisplay>();
		cd.turnCardSide(buttonController.activeZone);
		selected = false;
	}


	public bool validarPosicionDeCarta()
	{
		Card actual = this.GetComponent<CardDisplay>().card;
		int annoActual = actual.anno;
		int mesActual = actual.mes;
		int diaActual = actual.dia;

		int annoIzq = 1000;
		int mesIzq = 1;
		int diaIzq = 1;
		if (thisIndex > 0)
		{
			Card izq = this.transform.parent.GetChild(thisIndex - 1).GetComponent<CardDisplay>().card;
			annoIzq = izq.anno;
			mesIzq = izq.mes;
			diaIzq = izq.dia;
		}

		int annoDer = 2020;
		int mesDer = 5;
		int diaDer = 13;
		if (thisIndex < this.transform.parent.childCount-1)
		{
			Card der = this.transform.parent.GetChild(thisIndex + 1).GetComponent<CardDisplay>().card;
			annoDer = der.anno;
			mesDer = der.mes;
			diaDer = der.dia;

		}

		Debug.Log("Fecha Actual: " + diaActual + "/" + mesActual + "/" + annoActual);
		Debug.Log("Fecha Izq: " + diaIzq + "/" + mesIzq + "/" + annoIzq);
		Debug.Log("Fecha Der: " + diaDer + "/" + mesDer + "/" + annoDer);

		System.DateTime fechaActual = new System.DateTime(annoActual,mesActual,diaActual);
		System.DateTime fechaIzq = new System.DateTime(annoIzq, mesIzq, diaIzq);
		System.DateTime fechaDer = new System.DateTime(annoDer, mesDer, diaDer);

		if(fechaIzq <= fechaActual && fechaActual <= fechaDer)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	//Set
	public void setPlayed(bool value)
	{
		if (value)
		{
			this.HighlightForTimeline();
		}
		this.played = value;
	}


	private void Temporal()
	{
		this.thisIndex = this.transform.GetSiblingIndex();

		if (buttonController.index == thisIndex) //zona == buttonController.activeZona
		{
			if (!current)
			{
				Debug.Log("Card Pos: " + this.transform.GetSiblingIndex());
				this.GetComponent<UnityEngine.UI.Image>().color = new Color32(0, 255, 0, 255);
				Vector3 scaleChange = new Vector3(0.06f, 0.06f, 0f);
				this.transform.localScale += scaleChange;
				current = true;

			}

			else if (current)
			{
				if (Input.GetKeyDown("up"))
				{
					//activar selected
					handIndex = thisIndex;
					this.transform.SetParent(buttonController.timeline.transform);
					this.transform.SetSiblingIndex(buttonController.timeline.transform.childCount / 2);
					buttonController.activeZone = 1;
					zona = buttonController.activeZone;
				}
				/*else if (Input.GetKeyDown("down"))
				{					
					this.transform.SetParent(buttonController.hand.transform);
					this.transform.SetSiblingIndex(buttonController.hand.transform.childCount/2);
					buttonController.activeZona = 0;
					zona = buttonController.activeZona;
				}*/
}
			else
			{
				this.GetComponent<UnityEngine.UI.Image>().color = new Color32(0, 255, 0, 255);
			}
		}
		else if (selected)
		{

		}
		else
		{
			current = false;
			this.GetComponent<UnityEngine.UI.Image>().color = new Color32(0, 0, 255, 255);
			Vector3 scaleChange = new Vector3(1f, 1f, 0f);
			this.transform.localScale = scaleChange;
		}
	} 
	 



}
