﻿using System.Collections;
using System.Collections.Generic;
using System.Deployment.Internal;
using UnityEngine;
using UnityEngine.UI;

public class TurnSystem : MonoBehaviour
{

    public static TurnSystem instance;

    public Text jugadorActual;
    public Text mensaje;

    public int currentPlayer = 0;


    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    // Start is called before the first frame update
    void Start()
    {       
        for(int i = 0; i < PersistantManager.allPlayers.Count; i++)
        {
            //Debug.Log(PersistantManager.allPlayers[i].usuario);
            //crear una mano de 4 y asignarsela al jugador
            PersistantManager.allPlayers[i].SetPlayerHand( Deck.instance.CreateNewHand(4) );

            //setear el primer jugador con un random y asignar jugador activo
            int jugadorInicial = Random.Range(0, PersistantManager.allPlayers.Count);
            PersistantManager.instance.jugadorActual = currentPlayer = jugadorInicial;     
            
            //colocar mano del jugador en la zona de mano
            Deck.instance.PlaceHandInHandZone(PersistantManager.allPlayers[jugadorInicial].GetHand());

            jugadorActual.text = PersistantManager.instance.getCurrentPlayer();

        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ChangeTurn(int id)
    {

        PersistantManager.allPlayers[currentPlayer].RemoveCardFromPlayerHand(id);

        PersistantManager.instance.jugadorActual = currentPlayer = (++PersistantManager.instance.jugadorActual) % PersistantManager.allPlayers.Count;

        Deck.instance.PlaceHandInHandZone(PersistantManager.allPlayers[currentPlayer].GetHand());

        jugadorActual.text = PersistantManager.instance.getCurrentPlayer();


        //cambiar el nombre que se muestra en la pantalla
    }

    public void FailedPlay()
    {
        PersistantManager.allPlayers[currentPlayer].AddCardToPlayerHand( Deck.instance.GetNewCard() );
    }


    public void changeMessage(int estado)
    {
        if (estado == 1)
        {
            mensaje.color = Color.green;
            mensaje.text = "¡Posición Correcta!";
        }
        else if (estado == 2)
        {

            mensaje.color = Color.red;
            mensaje.text = "¡Posición Incorrecta!";
        }
        else if (estado == 3)
        {
            mensaje.color = Color.white;
            mensaje.text = "¡"+ PersistantManager.instance.getCurrentPlayer() + " ganó el juego!";
        }
        else
        {
            mensaje.color = Color.white;
            mensaje.text = "";
        }

    }




}
