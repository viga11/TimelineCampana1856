﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PersistantManager : MonoBehaviour
{
    //Singleton para guardar los jugadores en el momento del juego
    // Guarda el ultimo jugador registrado o el usuario en uso
    public static PersistantManager instance;
	public static List<PlayerData> allPlayers = new List<PlayerData>();
    public static string usuarioEnUso;
    public int jugadorActual;

    private void Awake()
    {
        if(instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }       

    }

    public void PrintAllPlayer()
    {
        Debug.Log("Entro a la funcion");
        for(int i = 0; i < allPlayers.Count; i++)
        {
            Debug.Log("Jugador " + i + "\n\t Nombre: " + allPlayers[i].nombre);
            Debug.Log("\n\t Apellido: " + allPlayers[i].apellido);
        }
        
    }


    public string getCurrentPlayer()
    {
        return allPlayers[jugadorActual].usuario;
    }


}
