﻿
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

public static class SaveSystem 
{
//Guardado general de todos los usuarios
			public static void SavePlayer(string nombre, string apellido, string usuario , string personaje){
			BinaryFormatter formatter = new BinaryFormatter();
			string path = Application.persistentDataPath + "/"+usuario+".ply";
			FileStream stream = new FileStream(path,FileMode.Create);
			PlayerData data = new PlayerData( nombre,  apellido,  usuario , personaje);
			PersistantManager.allPlayers.Add(new PlayerData( nombre,  apellido,  usuario , personaje));

			formatter.Serialize(stream,data);
			stream.Close();		
	}


	public static PlayerData LoadPlayer(string usuario)
	{
	//Cargar el Player Data por nombre de usuario
		string path = Application.persistentDataPath + "/"+usuario+".ply";
		if(File.Exists(path))
		{
			BinaryFormatter formatter = new BinaryFormatter();
			FileStream stream = new FileStream(path,FileMode.Open);
			PlayerData data = formatter.Deserialize(stream) as PlayerData;
			stream.Close();
			return data;
		}else
		{
			Debug.LogError("Save File not found " + path);
			return null;
		}
	}
	public static PlayerData LoadPlayerByPath(string path)
	{
	//Cargar el Player Data por path
			if(File.Exists(path))
			{
				BinaryFormatter formatter = new BinaryFormatter();
				FileStream stream = new FileStream(path,FileMode.Open);
				PlayerData data = formatter.Deserialize(stream) as PlayerData;
				stream.Close();
				return data;
			}else
			{
				Debug.LogError("Save File not found " + path);
				return null;
			}
	
	}
  

}



