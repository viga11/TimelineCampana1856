﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
using System.Linq;
public class PlayerList : MonoBehaviour
{



    //Manejo de la lista de los Usuarios que se registraron para jugar 
    //Manejo de la lista total de los Usuarios que han jugado el juego
    public List<string> PlayerListAll = new List<string>();
    List<PlayerData> PlayerListTurnsAll = new List<PlayerData>();
    List<PlayerData> generalPlayerListTurnsAll = new List<PlayerData>();
    private int turn;
    public Text turnText;
    enum GameState { PlayerTurn, Profile, Final }
    void Start()
    {
        AllPlayersDir();
        PlayerListTurnsAll = PersistantManager.allPlayers;
        turn = 0;
        if (PlayerListTurnsAll.Any())
        {
            turnText.text = PlayerListTurnsAll[turn].usuario;
        }
    }
    public void AllPlayersDir()
    {
        //Procesa el Directorio de todos los usuarios y los carga en la aplicación por Strings
        ProcessDirectory();
    }
    public void generalAllPlayerListInformation()
    {
        //Genera la lista de usuarios de los Strings a objetos PlayerData usando el Path
        AllPlayersDir();
        for (int i = 0; i < PlayerListAll.Count; i++)
        {
            generalPlayerListTurnsAll.Add(SaveSystem.LoadPlayerByPath(PlayerListAll[i]));
        }

    }
    public void allPlayerListInformation()
    {
        //Gira la lista de todos los usuarios en juego actualmente
        turn++;
        if (turn < PlayerListTurnsAll.Count)
        {
            turnText.text = PlayerListTurnsAll[turn].usuario;
        }
        else
        {
            turn = 0;
            turnText.text = PlayerListTurnsAll[turn].usuario;
        }
    }
    public void LoadAllPlayerListInformation()
    {
        //Gira la lista de Usuario Totales en haber jugado
        turn++;
        if (turn < PlayerListAll.Count)
        {
            Load.loadPersonajePath(PlayerListAll[turn]);
        }
        else
        {
            turn = 0;
            Load.loadPersonajePath(PlayerListAll[turn]);
        }
    }
    public void addPlayerFile(string path)
    {
        //Agrega el path de un usuario viejo a la lista
        PlayerListAll.Add(path);

    }
    public void ProcessDirectory()
    {
        //Procesa el directorio de los usuarios
        string[] fileEntries = Directory.GetFiles(Application.persistentDataPath);
        foreach (string fileName in fileEntries)
            ProcessFile(fileName);

    }

    public void ProcessFile(string path)
    {
        addPlayerFile(path);
    }
}
