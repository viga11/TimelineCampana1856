﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class DropZone : MonoBehaviour, IDropHandler, IPointerEnterHandler, IPointerExitHandler
{

    public enum Slot {TIMELINE, HAND, DECK}
    public Slot typeOfZone = Slot.TIMELINE;

    //public Draggable.Slot typeOfZone = Draggable.Slot.TIMELINE;

    public void OnPointerEnter(PointerEventData eventData){
        //Debug.Log("OnPointerEnter");
        if(eventData.pointerDrag == null){
            return;
        }
        Draggable d = eventData.pointerDrag.GetComponent<Draggable>();
        if(d != null){
            //if(typeOfZone == d.typeOfZone){
                d.placeholderParent = this.transform;
            //}
        }
    }

    public void OnPointerExit(PointerEventData eventData){
        //Debug.Log("OnPointerExit");
        if(eventData.pointerDrag == null){
            return;
        }
        Draggable d = eventData.pointerDrag.GetComponent<Draggable>();
        if(d != null && d.placeholderParent == this.transform){
            //if(typeOfZone == d.typeOfZone){
                d.placeholderParent = d.parentToReturnTo;
            //}
            
        }
    }

    public void OnDrop(PointerEventData eventData){
        //Debug.Log(eventData.pointerDrag.name + " was dropped on " + gameObject.name);
        Draggable d = eventData.pointerDrag.GetComponent<Draggable>();
        //AQUI VA EL CODIGO
        if(d != null){ //si el draggable no es null
            //Debug.Log("Entra al if:\n");
            //Debug.Log("\td.parentToReturnTo = " + d.parentToReturnTo);
           // Debug.Log("\tthis.transform = " + this.transform);



            if (this.typeOfZone == Slot.TIMELINE)
            {
                int pos = d.placeholder.transform.GetSiblingIndex();
                int annoCartaJugada = eventData.pointerDrag.GetComponent<CardDisplay>().card.anno;
                //Debug.Log("Sí encuentra la carta...");

                int annoIzq, annoDer;

                //En caso que sea primero en el timeline
                if (pos == 0)
                {
                    annoIzq = 0;
                }
                else
                {
                    annoIzq = d.placeholder.transform.parent.GetChild(pos - 1).GetComponent<CardDisplay>().card.anno;
                }
                //En caso que sea último en el timeline
                if (pos + 1 == d.placeholder.transform.parent.childCount)
                {
                    annoDer = 2020;
                }
                else
                {
                    annoDer = d.placeholder.transform.parent.GetChild(pos + 1).GetComponent<CardDisplay>().card.anno;
                }

                if (d.validPosition(annoCartaJugada, annoIzq, annoDer))
                {
                    //Debug.Log("Esooo");
                    eventData.pointerDrag.transform.SetParent(d.parentToReturnTo);
                    eventData.pointerDrag.transform.SetSiblingIndex(d.placeholder.transform.GetSiblingIndex());
                    Destroy(d.placeholder);
                }
                else
                {
                    //eliminar la carta y llamar una nueva
                    //Debug.Log("La carta esta mal animal");
                    Destroy(eventData.pointerDrag);
                    Destroy(d.placeholder);
                    //deck.AddCardToHand();
                }
            }           

            //en caso que sí se pueda
            d.parentToReturnTo = this.transform; //set this dropzone as parent to return
            CardDisplay cd = eventData.pointerDrag.GetComponent<CardDisplay>();
            cd.setCardSide(typeOfZone);
            /*if (cd != null)
            {                
            }*/

        }        
    }


}
