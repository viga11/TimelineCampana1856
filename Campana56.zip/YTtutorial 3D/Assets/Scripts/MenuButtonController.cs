﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using NDream.AirConsole;
using Newtonsoft.Json.Linq;
using UnityEngine.SceneManagement;

public class MenuButtonController : MonoBehaviour {

	// Use this for initialization
	public int index;
	[SerializeField] bool keyDown;
	[SerializeField] int maxIndex;
	public AudioSource audioSource;

	void Start () {
		audioSource = GetComponent<AudioSource>();
	}

    void Awake()
    {
        AirConsole.instance.onMessage += OnMessage;
    }

    // Update is called once per frame
    void Update () {
        if (true)
        {
        
		if(Input.GetAxis ("Vertical") != 0){
			if(!keyDown){
				if (Input.GetAxis ("Vertical") < 0) {
                        if (index < maxIndex)
                        {
                            index++;
                        }
                        else
                        {
                            index = 0;
                        }
                    } else if(Input.GetAxis ("Vertical") > 0){
                        if (index > 0)
                        {
                            index--;
                        }
                        else
                        {
                            index = maxIndex;
                        }
                    }
				keyDown = true;
			}
		}else if (Input.GetKeyDown("p"))
            {
                if (index == 0)
                {
                    SceneManager.LoadScene(1);
                }
            }

         else{
			keyDown = false;
		}
        }
    }

    void OnMessage(int fromDeviceID, JToken data)
    {
        if (false) //Si la zona activa es la mano
        {
            //maxIndex = hand.transform.childCount - 1;
            //imprime en consola la informacion que recibe
            Debug.Log("Mensaje enviado por dispositivo: " + fromDeviceID + ", data: " + data);
            //filtros de la informacion por botones (entre las direcciones del pad y el boton)

            //filtro boton A
            if (data["element"] != null && data["element"].ToString().Equals("botonA"))
            {
                if (index == 0)
                {
                    SceneManager.LoadScene(1);
                }
                else if(index == 3)
                {
                    Debug.Log("CERRANDO JUEGO");
                    Application.Quit();
                }

            }
            //filtro boton B
            if (data["element"] != null && data["element"].ToString().Equals("botonB"))
            {

            }

            //filtro dpad
            //Debug.Log("Si llego "+ (data["data"]["pressed"].ToString().Equals("True")));
            if (data["element"] != null && data["element"].ToString().Equals("dpad") && (data["data"]["pressed"].ToString().Equals("True")))
            {
                //arriba pressed
                if (data["data"]["key"].ToString().Equals("up"))
                {
                    if (index > 0)
                    {
                        index--;
                    }
                    else
                    {
                        index = maxIndex;
                    }
                }
                //abajo
                else if (data["data"]["key"].ToString().Equals("down"))
                {

                    if (index < maxIndex)
                    {
                        index++;
                    }
                    else
                    {
                        index = 0;
                    }

                }
                //izquierda
                else if (data["data"]["key"].ToString().Equals("left"))
                {
                   
                }
                //derecha
                else if (data["data"]["key"].ToString().Equals("right"))
                {
                   
                }
            }
        }
    }

    void OnDestroy()
    {

        //unregister events
        if (AirConsole.instance != null)
        {
            AirConsole.instance.onMessage -= OnMessage;
        }
    }

}
