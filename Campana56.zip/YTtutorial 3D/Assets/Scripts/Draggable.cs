﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Draggable : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{

    //public DropZone.Slot typeOfZone = Draggable.Slot.TIMELINE;
   
    public Transform parentToReturnTo = null;
    public Transform placeholderParent = null;

    public GameObject placeholder = null;
      
    public void OnBeginDrag(PointerEventData eventData){
        //Debug.Log("OnBeginDrag");

        //Creates the placeholder for the card, "space" between cards to drop it
        placeholder = new GameObject();
        placeholder.transform.SetParent( this.transform.parent );        
    
        LayoutElement le = placeholder.AddComponent<LayoutElement>();        
        le.preferredWidth = this.GetComponent<RectTransform>().rect.width;
        le.preferredHeight = this.GetComponent<RectTransform>().rect.height;
        le.flexibleWidth = 0;
        le.flexibleHeight = 0;

        placeholder.transform.SetSiblingIndex( this.transform.GetSiblingIndex());

        parentToReturnTo = this.transform.parent;
        placeholderParent = parentToReturnTo;
        this.transform.SetParent( this.transform.parent.parent );

        GetComponent<CanvasGroup>().blocksRaycasts = false;

        DropZone[] zones = GameObject.FindObjectsOfType<DropZone>();
        //loop the array and make the valid dropzones glow, and turn it off on end drag
    }

    public void OnDrag(PointerEventData eventData){
        //Debug.Log("OnDrag");
        this.transform.position = eventData.position;

        if(placeholder.transform.parent != placeholderParent){
            placeholder.transform.SetParent(placeholderParent);
        }

        int newSiblingIndex = placeholderParent.childCount;

        for(int i = 0; i < placeholderParent.childCount; i++){
            if(this.transform.position.x < placeholderParent.GetChild(i).position.x){
                newSiblingIndex = i;
                if(placeholder.transform.GetSiblingIndex() < newSiblingIndex){
                    newSiblingIndex--;
                }
                break;
            }
        }

        placeholder.transform.SetSiblingIndex(newSiblingIndex);

    }

    public void OnEndDrag(PointerEventData eventData){
        //Debug.Log("OnEndDrag");

        //es un tipo timeline
        DropZone dp = placeholder.transform.parent.GetComponent<DropZone>();

        if(false && dp != null && dp.typeOfZone == DropZone.Slot.TIMELINE)
        {
            int pos = placeholder.transform.GetSiblingIndex();
            int annoCartaJugada = this.GetComponent<CardDisplay>().card.anno;

            int annoIzq, annoDer;

            //En caso que sea primero en el timeline
            if (pos == 0)
            {
                annoIzq = 0;
            }
            else
            {
                annoIzq = placeholder.transform.parent.GetChild(pos - 1).GetComponent<CardDisplay>().card.anno;
            }
            //En caso que sea último en el timeline
            if (pos + 1 == placeholder.transform.parent.childCount)
            {
                annoDer = 2020;
            }
            else
            {
                annoDer = placeholder.transform.parent.GetChild(pos + 1).GetComponent<CardDisplay>().card.anno;
            }

            if (validPosition(annoCartaJugada, annoIzq, annoDer))
            {
                //Debug.Log("Esooo");
                this.transform.SetParent(parentToReturnTo);
                this.transform.SetSiblingIndex(placeholder.transform.GetSiblingIndex());
                Destroy(placeholder);
            }
            else
            {
                //eliminar la carta y llamar una nueva
                //Debug.Log("La carta esta mal animal");
                Destroy(eventData.pointerDrag);
                Destroy(placeholder);                
                //deck.AddCardToHand();
            }
        }
        //Verificar pos de la carta con la fecha
        else
        {
            //Debug.Log("Yo soy el else que sirve");
            this.transform.SetParent(parentToReturnTo);
            this.transform.SetSiblingIndex(placeholder.transform.GetSiblingIndex());
            Destroy(placeholder);
        }
        

        //fix
        GetComponent<CanvasGroup>().blocksRaycasts = true;
    }

    public bool validPosition(int annoCartaJugada, int annoIzq, int annoDer)
    {        
        if (annoCartaJugada >= annoIzq && annoCartaJugada <= annoDer)
        {
            return true;
        }

        else
        {
            return false;
        }

    }
    
}

