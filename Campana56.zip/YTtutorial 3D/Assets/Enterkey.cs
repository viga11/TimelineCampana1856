﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class Enterkey : MonoBehaviour
{
    public GameObject MenuPrincipal,OptionsMenu; 
    public GameObject MenuPrimero,OptionPrimero,OptionCerrar;



    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    { 
        Menu();
    }
    public void Menu(){
        MenuPrincipal.SetActive(true);
        EventSystem.current.SetSelectedGameObject(null);
        EventSystem.current.SetSelectedGameObject(MenuPrimero);

    }
    public void OpenOptios(){
        MenuPrincipal.SetActive(false);
        OptionsMenu.SetActive(true);
        EventSystem.current.SetSelectedGameObject(null);
        EventSystem.current.SetSelectedGameObject(OptionPrimero);
    }
    public void CloseOptions(){
        OptionsMenu.SetActive(false);
        MenuPrincipal.SetActive(true);
        EventSystem.current.SetSelectedGameObject(null);
        EventSystem.current.SetSelectedGameObject(OptionCerrar);

    }
}
